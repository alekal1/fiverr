import json

d = {}

with open('items.json') as f:
    data = json.load(f)
    for elem in data['properties']:
        d[f'{elem["Value"]}'] = f'{elem["Name"]}'
    for el in data['Calls']:
        for i in el['properties']:
            d[f'{i["Value"]}'] = f'{i["Name"]}'
print(d)